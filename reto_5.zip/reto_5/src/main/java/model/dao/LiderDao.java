package model.dao;

//Estructura de datos
import java.util.ArrayList;

//Librerías para SQL y Base de Datos
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//Clase para conexión
import util.JDBCUtilities;

//Encapsulamiento de los datos
import model.vo.Lider;

public class LiderDao {

    public ArrayList<Lider> query_requerimiento_4() throws SQLException {
        Connection conexion = JDBCUtilities.getConnection();
        // Crea arreglo para almacenar objetos tipo Proyecto
        ArrayList<Lider> lideres = new ArrayList<Lider>();
        // Consultas
        PreparedStatement pStatement = conexion.prepareStatement("SELECT Nombre, Primer_Apellido FROM Lider l INNER JOIN Proyecto p ON p.ID_Lider = l.ID_Lider WHERE p.Clasificacion = 'Casa';");
        ResultSet resultSet = pStatement.executeQuery();

        while(resultSet.next()) {
            Lider lider = new Lider(resultSet.getString("Nombre"), resultSet.getString("Primer_Apellido"));

            lideres.add(lider);
        }

        return lideres;
    }// Fin del método query_requerimiento_4

}