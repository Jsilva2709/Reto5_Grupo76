package model.dao;

//Estructura de datos
import java.util.ArrayList;

import model.vo.Lider;
import model.vo.Proyecto;

//Librerías para SQL y Base de Datos
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//Clase para conexión
import util.JDBCUtilities;

public class ProyectoDao {

    public ArrayList<Proyecto> query_requerimiento_1() throws SQLException {
        ArrayList<Proyecto> proyectos = new ArrayList<>();

        PreparedStatement pStatement = JDBCUtilities.getConnection().prepareStatement("SELECT Constructora, Serial FROM Proyecto WHERE Clasificacion = 'Casa'");
        ResultSet resultSet = pStatement.executeQuery();

        while(resultSet.next()) {
            Proyecto proyecto = new Proyecto();

            proyecto.setNombre_constructora(resultSet.getString("Constructora"));
            proyecto.setSerial(resultSet.getString("Serial"));

            proyectos.add(proyecto);
        }

        return proyectos;
    }

    public ArrayList<Proyecto> query_requerimiento_2() throws SQLException {
        ArrayList<Proyecto> proyectos = new ArrayList<>();

        PreparedStatement pStatement = JDBCUtilities.getConnection().prepareStatement("SELECT Numero_Habitaciones, Numero_Banos, Nombre, Primer_Apellido, Estrato FROM Proyecto p INNER JOIN Lider l ON l.ID_Lider = p.ID_Lider INNER JOIN Tipo t ON t.ID_Tipo = p.ID_Tipo WHERE p.Clasificacion = 'Casa';");
        ResultSet resultSet = pStatement.executeQuery();

        while(resultSet.next()) {
            Proyecto proyecto = new Proyecto();
            Lider lider = new Lider(resultSet.getString("Nombre"), resultSet.getString("Primer_Apellido"));

            proyecto.setNum_habitaciones(resultSet.getInt("Numero_Habitaciones"));
            proyecto.setNum_banios(resultSet.getInt("Numero_Banos"));
            proyecto.setLider(lider);
            proyecto.setEstrato_proyecto(resultSet.getInt("Estrato"));

            proyectos.add(proyecto);
        }

        return proyectos;
    }// Fin del método query_requerimiento_2


    public ArrayList<Proyecto> query_requerimiento_3() throws SQLException {
        ArrayList<Proyecto> proyectos = new ArrayList<>();
        
        PreparedStatement pStatement = JDBCUtilities.getConnection().prepareStatement("SELECT COUNT(*) AS Casas, Constructora FROM Proyecto GROUP BY Constructora , Clasificacion HAVING Clasificacion = 'Casa';");
        ResultSet resultSet = pStatement.executeQuery();

        while(resultSet.next()) {
            Proyecto proyecto = new Proyecto();

            proyecto.setNum_casas(resultSet.getInt("Casas"));
            proyecto.setNombre_constructora(resultSet.getString("Constructora"));

            proyectos.add(proyecto);
        }

        return proyectos;
    }// Fin del método query_requerimiento_3


    public ArrayList<Proyecto> query_requerimiento_5() throws SQLException{
        ArrayList<Proyecto> proyectos = new ArrayList<>();

        PreparedStatement pStatement = JDBCUtilities.getConnection().prepareStatement("SELECT COUNT(*) AS Casas, Constructora FROM Proyecto p GROUP BY Constructora, Clasificacion HAVING Casas >= 18 AND Clasificacion = 'Casa'ORDER BY Casas ASC");
        ResultSet resultSet = pStatement.executeQuery();

        while(resultSet.next()) {
            Proyecto proyecto = new Proyecto();

            proyecto.setNum_casas(resultSet.getInt("Casas"));
            proyecto.setNombre_constructora(resultSet.getString("Constructora"));

            proyectos.add(proyecto);
        }

        return proyectos;
    }// Fin del método query_requerimiento_4

}