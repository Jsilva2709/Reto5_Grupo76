package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

import controller.Controlador;
import model.vo.Proyecto;

public class VentanaRequerimiento2 extends JFrame {
    // Atributos
    private Controlador controlador = new Controlador();
    private JLabel info;
    private TextArea resultado2;

    // Constructor
    public VentanaRequerimiento2() {
        // Títilo
        this.setTitle(">~- Requerimiento 2 -~<");

        // Ubicación y tamaño
        this.setBounds(0, 0, 500, 460);
        this.setResizable(false);
        this.setLocationRelativeTo(null);

        // Layout
        this.setLayout(null);

        // Elementos gráficos
        // Lables
        info = new JLabel();
        info.setBounds(10, 10, 500, 50);
        info.setText("La siguente información es el resultado del REQUERIMIENTO 2: ");
        info.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        this.add(info);
        // Área Texto 
        resultado2 = new TextArea();
        resultado2.setBounds(10, 70, this.getWidth() - 30, this.getHeight() - 90);
        resultado2.setEditable(false);
        resultado2.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
        resultado2.setForeground(Color.BLACK);
        resultado2.setBackground(Color.LIGHT_GRAY);
        try {
            ArrayList<Proyecto> proyectos = controlador.Solucionar_requerimiento_2();
            for(int i = 0; i < 50; i++) {
                String numHabitaciones = ""+proyectos.get(i).getNum_habitaciones();
                String numBanos = ""+proyectos.get(i).getNum_banios();
                String nomLider = proyectos.get(i).getLider().getNombre();
                String apeLider = proyectos.get(i).getLider().getApellido();
                String estrato = ""+proyectos.get(i).getEstrato_proyecto();

                String respuesta = "\t->NÚMERO HABITACIONES:\t " + ">" + numHabitaciones;
                respuesta += "\n\t->NÚMERO BAÑOS:\t\t " + ">" + numBanos;
                respuesta += "\n\n\t->NOMBRE LIDER:\t\t " + ">" + nomLider;
                respuesta += "\n\t->APELLIDO LIDER:\t\t " + ">" + apeLider;
                respuesta += "\n\n\t->ESTRATO PROYECTO:\t " + ">" + estrato;
                respuesta += "\n-----------------------------------------------------------------------------------------------------------------------------\n";

                resultado2.append(respuesta);
            }
        } catch (SQLException e) {
            System.err.println("Ha ocurrido un error!" + e.getMessage());
        }
        this.add(resultado2);
    }
}
