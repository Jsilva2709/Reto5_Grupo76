package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

import controller.Controlador;
import model.vo.Proyecto;

public class VentanaRequerimiento5 extends JFrame {
    // Atributos
    private Controlador controlador = new Controlador();
    private JLabel info;
    private TextArea resultado5;

    // Constructor
    public VentanaRequerimiento5() {
        // Títilo
        this.setTitle(">~- Requerimiento 5 -~<");

        // Ubicación y tamaño
        this.setBounds(0, 0, 500, 450);
        this.setResizable(false);
        this.setLocationRelativeTo(null);

        // Layout
        this.setLayout(null);

        // Elementos gráficos
        // Lables
        info = new JLabel();
        info.setBounds(10, 10, 500, 50);
        info.setText("La siguente información es el resultado del REQUERIMIENTO 5: ");
        info.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        this.add(info);
        // Área Texto 
        resultado5 = new TextArea();
        resultado5.setBounds(10, 70, this.getWidth() - 30, this.getHeight() - 90);
        resultado5.setEditable(false);
        resultado5.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
        resultado5.setForeground(Color.BLACK);
        resultado5.setBackground(Color.LIGHT_GRAY);
        try {
            ArrayList<Proyecto> proyectos = controlador.Solucionar_requerimiento_5();
            for(int i = 0; i < proyectos.size(); i++) {
                String cantCasas = ""+proyectos.get(i).getNum_casas();
                String constructora = proyectos.get(i).getNombre_constructora();

                String respuesta = "\t->CANTIDAD CASAS:\t\t " + ">" + cantCasas;
                respuesta += "\n\t->CONSTRUCTORA:\t " + ">" + constructora;
                respuesta += "\n-----------------------------------------------------------------------------------------------------------------------------\n";

                resultado5.append(respuesta);
            }
        } catch (SQLException e) {
            System.err.println("Ha ocurrido un error!" + e.getMessage());
        }
        this.add(resultado5);
    }
}
