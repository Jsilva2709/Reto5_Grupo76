package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.TextArea;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

import controller.Controlador;
import model.vo.Lider;

public class VentanaRequerimiento4 extends JFrame {
    // Atributos
    private Controlador controlador = new Controlador();
    private JLabel info;
    private TextArea resultado4;

    // Constructor
    public VentanaRequerimiento4() {
        // Título
        this.setTitle(">~- Requerimiento 4 -~<");

        // Ubicación y tamaño
        this.setBounds(0, 0, 500, 450);
        this.setResizable(false);
        this.setLocationRelativeTo(null);

        // Layout
        this.setLayout(null);

        // Elementos gráficos
        // Lables
        info = new JLabel();
        info.setBounds(10, 10, 500, 50);
        info.setText("La siguente información es el resultado del REQUERIMIENTO 4: ");
        info.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        this.add(info);
        // Área Texto 
        resultado4 = new TextArea();
        resultado4.setBounds(10, 70, this.getWidth() - 30, this.getHeight() - 90);
        resultado4.setEditable(false);
        resultado4.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
        resultado4.setForeground(Color.BLACK);
        resultado4.setBackground(Color.LIGHT_GRAY);
        try {
            ArrayList<Lider> lideres = controlador.Solucionar_requerimiento_4();
            for(int i = 0; i < lideres.size(); i++) {
                String nomLider = lideres.get(i).getNombre();
                String apeLider = lideres.get(i).getApellido();

                String respuesta = "\t\t->NOMBRE LIDER:\t " + ">" + nomLider;
                respuesta += "\n\t\t->APELLIDO LIDER:\t " + ">" + apeLider;
                respuesta += "\n-----------------------------------------------------------------------------------------------------------------------------\n";

                resultado4.append(respuesta);
            }
        } catch (SQLException e) {
            System.err.println("Ha ocurrido un error!" + e.getMessage());
        }
        this.add(resultado4);
    }
}
