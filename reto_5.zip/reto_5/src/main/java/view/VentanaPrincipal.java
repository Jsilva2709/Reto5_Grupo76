package view;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import controller.Controlador;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    // Atributos
    // Labels
    private JLabel info;
    // Botones
    private JButton btnRequerimiento1;
    private JButton btnRequerimiento2;
    private JButton btnRequerimiento3;
    private JButton btnRequerimiento4;
    private JButton btnRequerimiento5;

    // Constructor
    public VentanaPrincipal() {
        // Título
        this.setTitle(">~- RETO 5 -~<  >Grupo 76<");

        // Ubicación y tamaño
        this.setBounds(0, 0, 482, 385);
        this.setResizable(false);
        this.setLocationRelativeTo(null);

        // Cerrar
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Layout
        this.setLayout(null);

        // Elementos gráficos
        // Labels
        info = new JLabel();
        info.setBounds(15, 0, 450, 30);
        info.setText("Escoge una opción para ver el resultado: ");
        info.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        this.add(info);

        // Botones
        btnRequerimiento1 = new JButton();
        btnRequerimiento1.setBounds(10, 30, 220, 100);
        ImageIcon iconRequerimiento1 = new ImageIcon("images\\requerimiento1.PNG");
        btnRequerimiento1.setIcon(new ImageIcon(iconRequerimiento1.getImage().getScaledInstance(btnRequerimiento1.getWidth(), btnRequerimiento1.getHeight(), Image.SCALE_SMOOTH)));
        this.add(btnRequerimiento1);
        btnRequerimiento1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controlador.mostrarVentanaRequerimiento1();
            }
        });

        btnRequerimiento2 = new JButton();
        btnRequerimiento2.setBounds(235, 30, 220, 100);
        ImageIcon iconRequerimiento2 = new ImageIcon("images\\requerimiento2.PNG");
        btnRequerimiento2.setIcon(new ImageIcon(iconRequerimiento2.getImage().getScaledInstance(btnRequerimiento2.getWidth(), btnRequerimiento2.getHeight(), Image.SCALE_SMOOTH)));
        this.add(btnRequerimiento2);
        btnRequerimiento2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controlador.mostrarVentanaRequerimiento2();
            }
        });

        btnRequerimiento3 = new JButton();
        btnRequerimiento3.setBounds(10, 135, 220, 100);
        ImageIcon iconRequerimiento3 = new ImageIcon("images\\requerimiento3.PNG");
        btnRequerimiento3.setIcon(new ImageIcon(iconRequerimiento3.getImage().getScaledInstance(btnRequerimiento3.getWidth(), btnRequerimiento3.getHeight(), Image.SCALE_SMOOTH)));
        this.add(btnRequerimiento3);
        btnRequerimiento3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controlador.mostrarVentanaRequerimiento3();
            }
        });

        btnRequerimiento4 = new JButton() ;
        btnRequerimiento4.setBounds(235, 135, 220, 100);
        ImageIcon iconRequerimiento4 = new ImageIcon("images\\requerimiento4.PNG");
        btnRequerimiento4.setIcon(new ImageIcon(iconRequerimiento4.getImage().getScaledInstance(btnRequerimiento4.getWidth(), btnRequerimiento4.getHeight(), Image.SCALE_SMOOTH)));
        this.add(btnRequerimiento4);
        btnRequerimiento4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controlador.mostrarVentanaRequerimiento4();
            }
        });

        btnRequerimiento5 = new JButton();
        btnRequerimiento5.setBounds(120, 240, 220, 100);
        ImageIcon iconRequerimiento5 = new ImageIcon("images\\requerimiento5.PNG");
        btnRequerimiento5.setIcon(new ImageIcon(iconRequerimiento5.getImage().getScaledInstance(btnRequerimiento5.getWidth(), btnRequerimiento5.getHeight(), Image.SCALE_SMOOTH)));
        this.add(btnRequerimiento5);
        btnRequerimiento5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Controlador.mostrarVentanaRequerimiento5();
            }
        });
    }
}
