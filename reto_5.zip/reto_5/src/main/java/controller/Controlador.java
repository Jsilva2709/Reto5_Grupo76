package controller;

//Estructuras de datos (colecciones)
import java.util.ArrayList;

import model.dao.LiderDao;
import model.dao.ProyectoDao;
import model.vo.Lider;
import model.vo.Proyecto;
import view.VentanaPrincipal;
import view.VentanaRequerimiento1;
import view.VentanaRequerimiento2;
import view.VentanaRequerimiento3;
import view.VentanaRequerimiento4;
import view.VentanaRequerimiento5;

//Librerías para bases de datos
import java.sql.SQLException;

public class Controlador {

    private final ProyectoDao proyectoDao;
    private final LiderDao liderDao;

    public Controlador() {
        this.proyectoDao = new ProyectoDao();
        this.liderDao = new LiderDao();
    }


    public ArrayList<Proyecto> Solucionar_requerimiento_1() throws SQLException {
        return this.proyectoDao.query_requerimiento_1();
    }

    public ArrayList<Proyecto> Solucionar_requerimiento_2() throws SQLException {
        return this.proyectoDao.query_requerimiento_2();
    }

    public ArrayList<Proyecto> Solucionar_requerimiento_3() throws SQLException {
        return this.proyectoDao.query_requerimiento_3();
    }

    public ArrayList<Lider> Solucionar_requerimiento_4() throws SQLException {
        return this.liderDao.query_requerimiento_4();
    }

    public ArrayList<Proyecto> Solucionar_requerimiento_5() throws SQLException {
        return this.proyectoDao.query_requerimiento_5();
    }

    public static void mostrarVentanaPrincipal() {
        VentanaPrincipal objVentanaPrincipal = new VentanaPrincipal();
        objVentanaPrincipal.setVisible(true);
    }

    public static void mostrarVentanaRequerimiento1() {
        VentanaRequerimiento1 objVentanaRequerimiento1 = new VentanaRequerimiento1();
        objVentanaRequerimiento1.setVisible(true);
    }

    public static void mostrarVentanaRequerimiento2() {
        VentanaRequerimiento2 objVentanaRequerimiento2 = new VentanaRequerimiento2();
        objVentanaRequerimiento2.setVisible(true);
    }

    public static void mostrarVentanaRequerimiento3() {
        VentanaRequerimiento3 objVentanaRequerimiento3 = new VentanaRequerimiento3();
        objVentanaRequerimiento3.setVisible(true);
    }

    public static void mostrarVentanaRequerimiento4() {
        VentanaRequerimiento4 objVentanaRequerimiento4 = new VentanaRequerimiento4();
        objVentanaRequerimiento4.setVisible(true);
    }

    public static void mostrarVentanaRequerimiento5() {
        VentanaRequerimiento5 objVentanaRequerimiento5 = new VentanaRequerimiento5();
        objVentanaRequerimiento5.setVisible(true);
    }
}
