import controller.Controlador;

public class App {
    public static void main(String[] args) {
        Controlador.mostrarVentanaPrincipal();
    }
}
